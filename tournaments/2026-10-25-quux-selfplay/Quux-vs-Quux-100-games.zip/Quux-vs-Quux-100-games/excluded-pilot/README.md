These two pilot games and their 88 turns are excluded from the official 100-game results.
