# Quux Bot 1 versus Quux Bot 2 — 100 measured games

Read `report.md` for findings, `summary.csv` for all scheduled outcomes, and `statistics.json` for numerical summaries. Each `game-NNN.jsonl` records original engine output, full boards, timings, native referee decisions and the final result; `game-NNN.txt` is a readable transcript.

`protocol.json` contains all 100 scheduled games and the 50 paired starting positions. `source-manifest.json` identifies the unmodified Quux version and source hashes. `verification.json` records the independent replay through the website rules. Pilot games are excluded.

Bot 1 is always North/player 0; Bot 2 is always South/player 1. Starting bot alternates, and each pair uses the identical initial board. A turn is one complete player turn. A repetition stop is an adjudication, not a rulebook draw; a failed search, timeout or illegal turn never awards the other bot a win.

## Reproduce

The `source/` directory includes the actual native binaries, runner, referee adapter, Quux core sources, website bridge and license. Original search sources are unchanged. `source/quux-selfplay/build.sh` is the original workspace build invocation; `reproduce-build.sh` is its portable equivalent for the packaged layout.

On Linux with Python 3.12+, g++ and make:

```sh
bash source/quux-selfplay/reproduce-build.sh
python3 source/quux-selfplay/run.py --games 100 --workers 4 --folder fresh-run
```

A fresh run writes a separate results directory. To independently check and report it, clone `https://github.com/butbra/Homeworlds`, run `npm ci` there, then:

```sh
node source/quux-selfplay/verify.mjs source/quux-selfplay/results/fresh-run /path/to/Homeworlds
python3 source/quux-selfplay/report.py source/quux-selfplay/results/fresh-run
```

The native setup routine uses the platform C library's seeded RNG, so `protocol.json` preserves the exact measured openings as well as the seeds. Search decisions are deterministic for a given position. Timings depend on hardware and load. Natural game results and nonterminal stops must remain separate in any comparison.

Quux is by Arthur O'Dwyer; see `source/quux/LICENSE`.
