#include <iostream>
#include <string>
#include <ctime>
#include <time.h>
#include <sys/time.h>
#include <cstdlib>
static double cpu_now(){timespec ts;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&ts);return ts.tv_sec+ts.tv_nsec*1e-9;}
#include <sstream>
#include "state.h"
#include "AI.h"
#include "ApplyMove.h"
int main(int argc,char**argv){
 std::string text,line;while(std::getline(std::cin,line)&&!line.empty())text+=line+"\n";
 int player=std::stoi(argv[2]);GameState st;if(!st.scan(text.c_str())){std::cerr<<"STATE_PARSE_ERROR\n";return 2;}
 if(std::string(argv[1])=="ai"){
  double budget=std::getenv("THINK_CPU_SECONDS")?std::atof(std::getenv("THINK_CPU_SECONDS")):1.0;
  itimerval timer{};timer.it_value.tv_sec=int(budget);timer.it_value.tv_usec=int((budget-int(budget))*1000000);setitimer(ITIMER_PROF,&timer,nullptr);
  auto start=cpu_now();auto move=get_ai_move(st,player);std::cerr<<"CPU "<<(cpu_now()-start)<<"\n";std::cout<<"CAND 1 "<<(cpu_now()-start)<<" "<<move.toString()<<std::endl;
 }else{
  std::getline(std::cin,line);bool used=false,sacrificed=false;int remaining=1;Color sacrifice=UNKNOWN_COLOR;int rc=0;
  std::istringstream input(line);std::string atom;
  if(line!="pass")while(std::getline(input,atom,';')){
   atom.erase(0,atom.find_first_not_of(" \t\r\n"));
   SingleAction action;if(!action.scan(atom.c_str())||!action.sanitycheck()){rc=90;break;}
   if(action.kind==SACRIFICE){if(used){rc=91;break;}used=true;sacrificed=true;sacrifice=action.piece.color;remaining=int(action.piece.size)+1;}
   else if(action.kind!=CATASTROPHE){
    Color c;if(!action.getAssociatedColor(&c)||remaining<=0){rc=92;break;}
    auto system=st.systemNamed(action.where.c_str());
    if(!system || (sacrificed?c!=sacrifice:!system->playerHasAccessTo(player,c))){rc=93;break;}
    --remaining;used=true;
   }
   auto result=ApplyMove::Single(st,player,action);
   // Quux Single leaves a temporarily empty own homeworld intact and returns SUICIDE.
   // Rules13 p10 allows restoring it before turn end, or losing if not restored.
   if(result!=ApplyMove::SUCCESS && result!=ApplyMove::SUICIDE){rc=int(result);break;}
  }
  std::cout<<"RESULT "<<rc<<" "<<st.hasLost(0)<<" "<<st.hasLost(1)<<"\n"<<st.toString();
 }
}
