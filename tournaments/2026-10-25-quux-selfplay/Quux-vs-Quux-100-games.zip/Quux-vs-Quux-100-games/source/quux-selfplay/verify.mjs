// Independently replay native tournament moves using the website's TypeScript rules.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const folder=path.resolve(process.argv[2]),webroot=process.argv[3]??'/workspace/Homeworlds';
const {createServer}=await import(pathToFileURL(path.join(webroot,'node_modules/vite/dist/node/index.js')));
const server=await createServer({root:webroot,configFile:false,server:{middlewareMode:true},appType:'custom'});
const report={games:0,turns:0,terminalGames:0,repetitionStopsConfirmed:0,rejectedTurns:0,terminalEmptyHomeworldNormalizations:0,engine:'Website TypeScript applyAction; independent of the native C++ referee'};
try{
 const {createInitialState,applyAction}=await server.ssrLoadModule('/src/game.ts');
 const {quuxPosition,quuxActions}=await server.ssrLoadModule('/src/quux.ts');
 const colors={r:'red',y:'yellow',g:'green',b:'blue'};
 const pieces=text=>(text.match(/[rygb][123]/g)??[]).map(code=>({color:colors[code[0]],size:Number(code[1])}));
 const native=text=>text.trim().split('\n').filter(Boolean).map(line=>{
  const m=/^(\w+)\s*\((?:([01]),\s*)?([rygb123]*)\)\s*([rygb123]*)-([rygb123]*)$/.exec(line);assert(m,line);
  return {name:m[1],home:m[2]===undefined?-1:Number(m[2]),stars:pieces(m[3]),ships:[pieces(m[4]),pieces(m[5])]};
 });
 const code=p=>p.color[0]+p.size;
 const normalized=(systems,terminal)=>systems.filter(s=>!terminal||s.home===-1||s.ships[0].length+s.ships[1].length>0).map(s=>[s.name,s.home,s.stars.map(code).sort(),...s.ships.map(f=>f.map(code).sort())]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 for(const filename of readdirSync(folder).filter(name=>/^game-\d+\.jsonl$/.test(name)).sort()){
  const events=readFileSync(path.join(folder,filename),'utf8').trim().split('\n').map(JSON.parse),start=events[0];
  const initial=native(start.initial_state),opening=[0,1].map(player=>{
   const home=initial.find(s=>s.home===player);assert(home);assert.equal(home.ships[player].length,1);
   return {stars:home.stars,shipColor:home.ships[player][0].color};
  });
  let state=createInitialState(opening,start.starter),turns=0;
  const positionKey=()=>JSON.stringify([state.player,state.systems.map(s=>[s.homeworld??-1,s.stars.map(code).sort(),...[0,1].map(owner=>s.ships.filter(p=>p.owner===owner).map(code).sort())]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)))]);
  const seen=new Map([[positionKey(),1]]);
  const aliases=new Map(initial.map(s=>[s.name,s.home===0?'north':'south']));
  for(const event of events){
   if(event.event!=='move'||event.status!=='ok'||!event.validation)continue;
   assert.equal(state.player,event.player,filename);assert.equal(event.turn,turns+1,filename);
   const ids=new Map([...quuxPosition(state).names].map(([name,id])=>[id,name]));
   const names=new Map([...aliases].filter(([,id])=>ids.has(id)).map(([name,id])=>[name,ids.get(id)]));
   const translated=event.move.replace(/\b[A-Za-z]\w*\b/g,name=>names.get(name)??name);
   if(!event.validation.legal){assert.throws(()=>quuxActions(state,translated));report.rejectedTurns++;continue;}
   const discoveries=[...event.move.matchAll(/\bto (\w+) \([rygb][123]\)/g)].map(m=>m[1]);
   const actions=quuxActions(state,translated);
   for(const action of actions){
    if(action.type==='discover')aliases.set(discoveries.shift(),`system-${state.nextSystem}`);
    state=applyAction(state,action);
   }
   assert.equal(discoveries.length,0);
   const terminal=event.validation.winner!==null;
   assert.equal(state.outcome==='playing'?null:state.outcome,event.validation.winner,filename);
   const website=state.systems.map(s=>({name:[...aliases].find(([,id])=>id===s.id)?.[0],home:s.homeworld??-1,stars:s.stars,ships:[0,1].map(owner=>s.ships.filter(p=>p.owner===owner))}));
   const reference=native(event.validation.state);
   if(terminal&&website.length!==reference.length)report.terminalEmptyHomeworldNormalizations++;
   assert.deepEqual(normalized(website,terminal),normalized(reference,terminal),`${filename} turn ${event.turn}`);
   assert.equal(state.bank.length+state.systems.reduce((n,s)=>n+s.stars.length+s.ships.length,0),36);
   turns++;report.turns++;if(terminal)report.terminalGames++;
   else {const key=positionKey();seen.set(key,(seen.get(key)??0)+1);}
  }
  const end=events.at(-1);assert.equal(end.event,'end');assert.equal(end.turns,turns,filename);
  if(end.status==='completed')assert.equal(end.winner,state.outcome==='draw'?'Draw':['Bot 1','Bot 2'][state.outcome]);
  if(end.status==='adjudicated'){
   assert.equal(end.reason,'threefold_repetition');assert((seen.get(positionKey())??0)>=3);assert.equal(state.outcome,'playing');assert.equal(end.winner,'');report.repetitionStopsConfirmed++;
  }
  report.games++;
 }
 writeFileSync(path.join(folder,'verification.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report));
}finally{await server.close();}
