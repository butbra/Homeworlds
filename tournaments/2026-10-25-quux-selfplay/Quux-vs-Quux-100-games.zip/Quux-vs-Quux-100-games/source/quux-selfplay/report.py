"""Summarize measured outcomes only; failed and adjudicated games earn no wins."""
import collections,csv,json,math,pathlib,statistics,sys
ROOT=pathlib.Path(__file__).resolve().parent

def distribution(values):
    values=sorted(values)
    if not values:return dict(count=0,mean=None,median=None,min=None,max=None,p95=None)
    return dict(count=len(values),mean=statistics.mean(values),median=statistics.median(values),min=values[0],max=values[-1],p95=values[max(0,math.ceil(len(values)*.95)-1)])

def main():
    folder=pathlib.Path(sys.argv[1]);protocol=json.loads((folder/'protocol.json').read_text());results=json.loads((folder/'results.json').read_text());rows=results['games']
    assert len(rows)==protocol['games']==100 and sorted(r['game']for r in rows)==list(range(1,101))
    verification=json.loads((folder/'verification.json').read_text());assert verification['games']==100 and verification['turns']==sum(r['turns']for r in rows)
    assert collections.Counter(r['starter']for r in rows)=={'Bot 1':50,'Bot 2':50}
    completed=[r for r in rows if r['status']=='completed'];decisive=[r for r in completed if r['winner']!='Draw']
    outcomes=collections.Counter(r['status']for r in rows);wins=collections.Counter(r['winner']for r in completed);order=collections.Counter(r['winning_order']for r in decisive)
    per_bot={bot:dict(starts=sum(r['starter']==bot for r in rows),wins=sum(r['winner']==bot for r in decisive),wins_first=sum(r['winner']==bot and r['winning_order']=='first'for r in decisive),wins_second=sum(r['winner']==bot and r['winning_order']=='second'for r in decisive))for bot in ['Bot 1','Bot 2']}
    decisions=[];decision_rows=[];actions=collections.Counter();pair_results=collections.Counter()
    for row in rows:
        events=[json.loads(line)for line in (folder/f"game-{row['game']:03d}.jsonl").read_text().splitlines()]
        start=events[0];assert start['initial_state']==protocol['schedule'][row['game']-1]['initial_state'];assert start['starter']==(row['game']-1)%2
        text=f"Game {row['game']:03d} — {start['labels'][start['starter']]} starts\nOpening:\n{start['initial_state']}\n"
        for event in events:
            if event['event']!='move':continue
            decisions.append(event)
            decision_rows.append(dict(game=row['game'],pair=row['pair'],starter=row['starter'],turn=event['turn'],bot=event['bot'],acts_first=event['bot']==row['starter'],status=event['status'],legal=event.get('validation',{}).get('legal',''),search_completed=event['search_completed'],wall_seconds=event['wall_seconds'],cpu_seconds=event['cpu_seconds'],search_cpu_seconds=event['search_cpu_seconds'],move=event['move']))
            text+=f"Turn {event['turn']} — {event['bot']} — {event['status']} — {event['wall_seconds']:.6f} seconds\n{event['move']}\n"
            if event.get('validation',{}).get('legal'):
                text+=event['validation']['state']+'\n'
                for part in event['move'].split(';'):
                    part=part.strip();kind=part.split()[0]
                    if kind=='convert':kind='trade'
                    if kind=='move'and part.endswith(')'):kind='discover'
                    actions[kind]+=1
            else:text+=event.get('stderr','')+'\n'
        text+=f"Result: {row['status']}; winner: {row['winner'] or 'none'}; {row['reason']}; {row['turns']} validated turns\n"
        (folder/f"game-{row['game']:03d}.txt").write_text(text)
    for pair in range(1,51):
        games=[r for r in rows if r['pair']==pair];assert len(games)==2
        if all(r['status']=='completed'and r['winner']!='Draw'for r in games):
            first_wins=sum(r['winning_order']=='first'for r in games)
            pair_results[{0:'second player wins both',1:'one first-player win and one second-player win',2:'first player wins both'}[first_wins]]+=1
        else:pair_results['pair contains a draw, adjudication or unfinished game']+=1
    successful=[d for d in decisions if d['status']=='ok']
    stats=dict(scheduled=100,naturally_completed=len(completed),decisive=len(decisive),statuses=dict(outcomes),wins=dict(wins),wins_by_order=dict(order),first_win_percent_decisive=100*order['first']/len(decisive)if decisive else None,second_win_percent_decisive=100*order['second']/len(decisive)if decisive else None,per_bot=per_bot,
        natural_game_turns=distribution([r['turns']for r in completed]),all_attempt_turns=distribution([r['turns']for r in rows]),decisive_game_turns=distribution([r['turns']for r in decisive]),
        total_validated_turns=sum(r['turns']for r in rows),passes=sum(r['passes']for r in rows),catastrophes=sum(r['catastrophes']for r in rows),games_with_catastrophe=sum(r['catastrophes']>0 for r in rows),actions=dict(actions),
        decision_wall_seconds=distribution([d['wall_seconds']for d in successful]),decision_cpu_seconds=distribution([d['cpu_seconds']for d in successful]),total_search_process_cpu_seconds=sum(d['cpu_seconds']for d in decisions),total_decision_wall_seconds=sum(d['wall_seconds']for d in decisions),elapsed_wall_seconds=results['elapsed_wall_seconds'],
        timeouts=sum(d['status']=='timeout'for d in decisions),illegal_turns=sum(d.get('validation',{}).get('legal')is False for d in decisions),failed_searches=sum(d['status']!='ok'for d in decisions),pair_results=dict(pair_results),verification=verification)
    (folder/'statistics.json').write_text(json.dumps(stats,indent=2)+'\n')
    with (folder/'turns.csv').open('w')as out:
        writer=csv.DictWriter(out,fieldnames=list(decision_rows[0]));writer.writeheader();writer.writerows(decision_rows)
    mean=lambda value:f'{value:.2f}'if value is not None else 'n/a'
    text='# Quux Bot 1 versus Quux Bot 2: 100 measured games\n\n'
    text+=f"All **100 scheduled games were executed**: **{len(completed)}** finished naturally under the rules, **{outcomes['adjudicated']}** stopped by repetition adjudication, and **{sum(v for k,v in outcomes.items()if k not in ['completed','adjudicated'])}** other unfinished/error games. Adjudications and software failures receive no winner.\n\n"
    text+='| Bot | Games started | Wins | Wins going first | Wins going second |\n|---|---:|---:|---:|---:|\n'
    for bot,values in per_bot.items():text+=f"| {bot} | {values['starts']} | {values['wins']} | {values['wins_first']} | {values['wins_second']} |\n"
    text+=f"| Total | 100 | {len(decisive)} | {order['first']} | {order['second']} |\n\n"
    text+=f"**First player:** {order['first']} wins ({mean(stats['first_win_percent_decisive'])}% of decisive games). **Second player:** {order['second']} wins ({mean(stats['second_win_percent_decisive'])}%). Natural simultaneous-elimination draws: **{wins['Draw']}**.\n\n"
    natural=stats['natural_game_turns'];overall=stats['all_attempt_turns']
    text+='## Game lengths\n\nA turn means one bot’s complete turn, including any sacrifice actions and free catastrophes. Two turns are approximately one round.\n\n'
    text+='| Cohort | Games | Average turns | Median | Shortest | Longest |\n|---|---:|---:|---:|---:|---:|\n'
    for name,value in [('Naturally completed games',natural),('All scheduled games, through their recorded stopping point',overall)]:text+=f"| {name} | {value['count']} | {mean(value['mean'])} | {value['median']} | {value['min']} | {value['max']} |\n"
    text+='\n## Additional measured statistics\n\n'
    text+=f"- Validated turns: {stats['total_validated_turns']:,}; native pass turns: {stats['passes']:,}.\n- Catastrophes: {stats['catastrophes']:,} across {stats['games_with_catastrophe']} games.\n- Mean computation time per successful full-turn decision: {stats['decision_wall_seconds']['mean']:.6f} s wall, {stats['decision_cpu_seconds']['mean']:.6f} s CPU. Longest decision: {stats['decision_wall_seconds']['max']:.6f} s wall.\n- Total search-process CPU: {stats['total_search_process_cpu_seconds']:.3f} s. Tournament wall time: {stats['elapsed_wall_seconds']:.3f} s with four parallel games. Animation delays are excluded.\n- Timeouts: {stats['timeouts']}; illegal turns: {stats['illegal_turns']}; failed searches: {stats['failed_searches']}.\n- Independent website rules replay: {verification['turns']:,} turns across {verification['games']} games; terminal winners agreed.\n\n"
    text+='## Unfinished or invalid games\n\n| Game | Validated turns | Status | Reason |\n|---|---:|---|---|\n'
    for row in rows:
        if row['status']not in ['completed','adjudicated']:text+=f"| {row['game']} | {row['turns']} | {row['status']} | {row['reason']} |\n"
    text+='\nThese games earn no winner. No completed search result was replaced by a partial candidate.\n\n'
    text+='## Paired opening results\n\n| Outcome across both games of a setup pair | Pairs |\n|---|---:|\n'
    for label,count in pair_results.items():text+=f'| {label} | {count} |\n'
    text+='\n## Method and limits\n\n'+protocol['method']+'\n\n'+protocol['scoring']+'\n\n'
    text+='Threefold repetition uses the same full board and player to move, ignoring cosmetic system names. It is a tournament stopping policy, not a rulebook draw. A 400-turn cap would be reported as unfinished. Search processes have no shortened iteration/depth or artificial animation waits; a 60-second safety timeout would leave the game unfinished, never award an opponent win.\n\n'
    text+='These are two copies of the same deterministic engine, not different-strength bots. Identity totals can reflect opening seats; the paired first/second-player comparison is the useful measurement here. The 50 distinct native-generated opening pairs are a sample, not all possible setups. The 100 games share 50 paired starting positions and should not be treated as 100 independent random setups.\n\n'
    text+='The native referee uses the original C++ legal-action primitives with a Rules13 whole-turn layer. Every accepted turn is independently replayed by the website’s TypeScript rules. Any terminal empty-homeworld cleanup differences are normalized only after both implementations agree on the winner; pieces, ownership and inventories are otherwise checked throughout.\n\n'
    text+='See `summary.csv` for all 100 outcomes, `statistics.json` for numerical results, `protocol.json` for the exact schedule/openings, and `game-NNN.jsonl` / `game-NNN.txt` for full transcripts. Pilot games are excluded from these results.\n'
    (folder/'report.md').write_text(text)
    print(json.dumps(stats,indent=2))

if __name__=='__main__':main()
