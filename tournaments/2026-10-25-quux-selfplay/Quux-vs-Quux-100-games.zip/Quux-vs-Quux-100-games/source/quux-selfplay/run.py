"""Measured Quux self-play, with fixed paired openings and auditable full turns."""
import argparse,collections,concurrent.futures,csv,datetime,hashlib,json,multiprocessing,os,pathlib,random,re,resource,signal,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
import tournament as rules
ENGINE=ROOT/'bin/quux'
LABELS=['Bot 1','Bot 2']

def atomic(path,data):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(data,indent=2));temp.replace(path)

def initial_positions(pairs):
    rng=random.Random(20261025);positions=[];seen=set()
    while len(positions)<pairs:
        order=[0,1]if len(positions)%2==0 else [1,0];state='';seeds=[]
        for player in order:
            seed=rng.getrandbits(32);seeds.append(dict(player=player,seed=seed))
            p=subprocess.run([str(ENGINE),'setup',str(player),str(seed)],input=state+'\n',text=True,capture_output=True,timeout=5,check=True)
            setup=p.stdout.strip();assert not setup.startswith('ERROR'),setup
            state+=re.sub(r'^Bot\b','North'if player==0 else 'South',setup)+'\n'
        systems=rules.parsed(state);assert len(systems)==2 and {s['home']for s in systems}=={0,1}
        # Keep native setup choices, but use the same North/South input order in every game.
        state='\n'.join(sorted(state.strip().splitlines(),key=lambda line:not line.startswith('North')))+'\n'
        signature=rules.key(state,0)
        if signature in seen:continue
        seen.add(signature);positions.append(dict(pair=len(positions)+1,initial_state=state,setup_seeds=seeds))
    return positions

def limits():
    resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def choose(state,player,seconds):
    before=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.monotonic()
    process=subprocess.Popen([str(ENGINE),'ai',str(player)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,preexec_fn=limits)
    expired=False
    try:stdout,stderr=process.communicate(state+'\n',timeout=seconds)
    except subprocess.TimeoutExpired:
        expired=True;os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate()
    wall=time.monotonic()-started;after=resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
    match=re.search(r'^CPU ([\d.e+-]+)$',stderr,re.M)
    status='timeout'if expired else 'ok'if process.returncode==0 and stdout.strip() and not stdout.startswith('ERROR')else 'engine_error'
    return dict(status=status,move=stdout.strip()if status=='ok'else '',cpu_seconds=cpu,search_cpu_seconds=float(match[1])if match else None,wall_seconds=wall,returncode=process.returncode,stdout=stdout,stderr=stderr,search_completed=status=='ok')

def worker_init(cpus):
    os.sched_setaffinity(0,{cpus[(multiprocessing.current_process()._identity[0]-1)%len(cpus)]})

def run_game(job,folder,seconds,maxturns):
    folder=pathlib.Path(folder);number=job['game'];path=folder/f'game-{number:03d}.jsonl';live=folder/f'game-{number:03d}.status.json'
    if path.exists():
        events=[json.loads(line)for line in path.read_text().splitlines()]
        if events and events[-1]['event']=='end':return {k:v for k,v in events[-1].items()if k not in ['event','at']}
        path.rename(path.with_suffix('.interrupted.jsonl'))
    player=job['starter'];state=job['initial_state'];seen=collections.Counter({rules.key(state,player):1});started=time.monotonic()
    row=dict(game=number,pair=job['pair'],starter=LABELS[player],status='unfinished',winner='',winning_order='',turns=0,reason='',bot1_turns=0,bot2_turns=0,bot1_cpu_seconds=0.,bot2_cpu_seconds=0.,bot1_wall_seconds=0.,bot2_wall_seconds=0.,passes=0,catastrophes=0,atomic_actions=0)
    with path.open('w')as output:
        def emit(event):output.write(json.dumps(dict(at=time.time(),**event))+'\n');output.flush()
        emit(dict(event='start',**job,labels=LABELS,turn_seconds=seconds,cpus=sorted(os.sched_getaffinity(0))))
        try:
            for turn in range(1,maxturns+1):
                atomic(live,dict(game=number,status='running',turn=turn,player=LABELS[player],decision_started=time.time()))
                choice=choose(state,player,seconds);prefix=f'bot{player+1}'
                row[prefix+'_cpu_seconds']+=choice['cpu_seconds'];row[prefix+'_wall_seconds']+=choice['wall_seconds']
                event=dict(event='move',turn=turn,player=player,bot=LABELS[player],state_before=state,**choice)
                if choice['status']!='ok':
                    row.update(status='unfinished'if choice['status']=='timeout'else 'engine_error',reason=choice['status']+':'+LABELS[player]);emit(event);break
                ref=rules.validate(state,player,choice['move']);event['validation']=ref;emit(event)
                if not ref['legal']:
                    row.update(status='illegal',reason=f"{LABELS[player]}:referee_code_{ref['code']}");break
                row[prefix+'_turns']+=1;row['turns']=turn
                atoms=[part.strip()for part in choice['move'].split(';')if part.strip()]
                row['passes']+=choice['move']=='pass';row['catastrophes']+=sum(a.startswith('catastrophe ')for a in atoms);row['atomic_actions']+=sum(a!='pass'for a in atoms)
                state=ref['state']
                if ref['winner']is not None:
                    winner=ref['winner'];row.update(status='completed',winner='Draw'if winner=='draw'else LABELS[winner],winning_order='draw'if winner=='draw'else 'first'if winner==job['starter']else 'second',reason='rulebook_terminal');break
                player=1-player;seen[rules.key(state,player)]+=1
                if seen[rules.key(state,player)]>=3:row.update(status='adjudicated',reason='threefold_repetition');break
            else:row.update(status='unfinished',reason=f'{maxturns}_turn_limit')
        except Exception as error:
            row.update(status='software_error',winner='',winning_order='',reason=repr(error));emit(dict(event='error',error=repr(error)))
        row.update(elapsed_wall_seconds=time.monotonic()-started,final_state=state);emit(dict(event='end',**row));atomic(live,row)
    return row

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--games',type=int,default=100);parser.add_argument('--workers',type=int,default=4);parser.add_argument('--seconds',type=float,default=60);parser.add_argument('--maxturns',type=int,default=400);parser.add_argument('--folder',default='official-100');args=parser.parse_args()
    assert args.games>0 and args.games%2==0
    folder=ROOT/'results'/args.folder;folder.mkdir(parents=True,exist_ok=True)
    import fcntl
    lock=(folder/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    protocol_path=folder/'protocol.json'
    if protocol_path.exists():
        protocol=json.loads(protocol_path.read_text());assert protocol['games']==args.games and protocol['seconds']==args.seconds and protocol['maxturns']==args.maxturns
    else:
        openings=initial_positions(args.games//2)
        protocol=dict(games=args.games,seconds=args.seconds,maxturns=args.maxturns,workers=args.workers,started_at=time.time(),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),engine_commit='20d2ec4a70365acc4b8ba8cd6bae7125fa935513',opening_seed=20261025,openings=openings,
          schedule=[dict(game=i+1,starter=i%2,**openings[i//2])for i in range(args.games)],
          method=f'Unmodified native get_ai_move, full search. Fresh process per complete turn, matching website worker lifetime. Identical search and 60-second safety ceiling for both copies; no partial answer accepted. Native CLI setup algorithm generates {args.games//2} distinct paired opening positions; setup selection order alternates by pair. Bot 1 always North/player 0; Bot 2 always South/player 1. Every pair reverses who moves first. One player turn counts as one turn, including any sacrifice actions and free catastrophes.',
          scoring=f'Exactly {args.games} fixed scheduled games; no outcome-based replacement or filtering. Natural rulebook wins and simultaneous-elimination draws only. Repetition adjudications, turn-limit stops, timeouts, illegal moves and software errors are separate and earn no win.',
          referee='Original Quux ApplyMove::Single plus existing Rules13 whole-turn adapter; full transcripts independently replayed through the website TypeScript rules engine.',
          resource_policy=f'{args.workers} parallel games, one CPU affinity per game, 4 GiB address space per search.',
          hashes={str(path.relative_to(ROOT.parent)):hashlib.sha256(path.read_bytes()).hexdigest()for path in [ENGINE,ROOT/'native.cc',ROOT/'run.py',ROOT/'build.sh',ROOT.parent/'adapters/quux.cc',ROOT.parent/'bin/quux-adapter',ROOT.parent/'tournament.py']})
        atomic(protocol_path,protocol)
    rows=[];context=multiprocessing.get_context('spawn');cpus=sorted(os.sched_getaffinity(0))[:args.workers]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,mp_context=context,initializer=worker_init,initargs=(cpus,))as pool:
        futures=[pool.submit(run_game,job,str(folder),args.seconds,args.maxturns)for job in protocol['schedule']]
        for future in concurrent.futures.as_completed(futures):
            row=future.result();rows.append(row);rows.sort(key=lambda r:r['game']);atomic(folder/'results.json',dict(finished=len(rows),scheduled=args.games,elapsed_wall_seconds=time.time()-protocol['started_at'],games=rows))
            temp=folder/'summary.csv.tmp'
            with temp.open('w')as out:
                writer=csv.DictWriter(out,fieldnames=[k for k in rows[0]if k!='final_state'],extrasaction='ignore');writer.writeheader();writer.writerows(rows)
            temp.replace(folder/'summary.csv');print(json.dumps({k:row[k]for k in ['game','starter','status','winner','winning_order','turns','reason']}),flush=True)
    print(json.dumps(dict(event='finished',games=len(rows),wall_seconds=time.time()-protocol['started_at'])),flush=True)

if __name__=='__main__':main()
