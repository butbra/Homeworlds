#!/usr/bin/env bash
set -euo pipefail
cd /workspace/tournament
test "$(git -C quux rev-parse HEAD)" = 20d2ec4a70365acc4b8ba8cd6bae7125fa935513
make -C quux -j2 homeworlds-cli
g++ -O2 -std=c++14 -Iquux/core-src quux-selfplay/native.cc /workspace/Homeworlds/vendor/quux/bridge.cc quux/{AllMoves,AIMove,AIStaticEval,PlanetNames,mprintf,PieceCollection,StarSystem,GameState,SingleAction,WholeMove,ApplyMove}.o -o quux-selfplay/bin/quux
