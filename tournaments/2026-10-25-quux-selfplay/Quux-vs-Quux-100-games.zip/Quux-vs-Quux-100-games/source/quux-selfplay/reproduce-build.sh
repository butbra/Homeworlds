#!/usr/bin/env bash
set -euo pipefail
selfplay_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$selfplay_dir/.."
if [ ! -d quux/core-src ]; then
  git clone https://github.com/Quuxplusone/Homeworlds.git quux
  git -C quux checkout --detach 20d2ec4a70365acc4b8ba8cd6bae7125fa935513
fi
mkdir -p bin quux-selfplay/bin
make -C quux -j2 homeworlds-cli
g++ -O2 -std=c++14 -Iquux/core-src quux-selfplay/native.cc quux-selfplay/bridge.cc quux/{AllMoves,AIMove,AIStaticEval,PlanetNames,mprintf,PieceCollection,StarSystem,GameState,SingleAction,WholeMove,ApplyMove}.o -o quux-selfplay/bin/quux
g++ -O2 -std=c++14 -Iquux/core-src adapters/quux.cc quux/{AllMoves,AIMove,AIStaticEval,PlanetNames,mprintf,PieceCollection,StarSystem,GameState,SingleAction,WholeMove,ApplyMove}.o -o bin/quux-adapter
