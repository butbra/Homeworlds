#include <ctime>
#include <iostream>
#include <string>
#include <time.h>
extern "C" const char *choose_move(const char *,int);
extern "C" const char *choose_setup(const char *,int,unsigned);
static double cpu_now(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
int main(int argc,char **argv){
 if(argc<3)return 2;
 std::string text,line;while(std::getline(std::cin,line)&&!line.empty())text+=line+"\n";
 const int player=std::stoi(argv[2]);
 if(std::string(argv[1])=="setup"){
  if(argc!=4)return 2;
  std::cout<<choose_setup(text.c_str(),player,std::stoul(argv[3]))<<std::endl;
 }else{
  const double started=cpu_now();
  const std::string move=choose_move(text.c_str(),player);
  std::cerr<<"CPU "<<cpu_now()-started<<"\n";
  std::cout<<move<<std::endl;
 }
}
