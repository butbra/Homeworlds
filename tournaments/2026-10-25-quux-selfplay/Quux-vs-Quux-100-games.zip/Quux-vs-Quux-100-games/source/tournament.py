#!/usr/bin/env python3
import argparse,concurrent.futures,collections,csv,hashlib,json,os,pathlib,random,re,resource,signal,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
BUDGET=1.0
WALL=1.0

def parsed(text):
 out=[]
 for line in text.strip().splitlines():
  m=re.fullmatch(r'(\w+)\s*\((?:(\d),\s*)?([rygb123]+)\)\s*([rygb123]*)-([rygb123]*)',line)
  if not m:raise ValueError('Bad canonical state: '+line)
  name,home,stars,a,b=m.groups();pieces=lambda s:re.findall('[rygb][123]',s)
  out.append(dict(name=name,home=int(home) if home is not None else -1,stars=pieces(stars),ships=[pieces(a),pieces(b)]))
 counts=collections.Counter(p for s in out for p in s['stars']+sum(s['ships'],[]))
 if any(v>3 for v in counts.values()):raise ValueError('Inventory exceeds bank: '+str(counts))
 return out

def cztext(state):
 return ''.join(f"{s['name']} {s['home']} {''.join(s['stars'])} {sum(map(len,s['ships']))} "+' '.join(f'{i} {p}' for i,ps in enumerate(s['ships']) for p in ps)+'\n' for s in parsed(state))

def key(state,player):
 return json.dumps([player,sorted((s['home'],''.join(sorted(s['stars'])),''.join(sorted(s['ships'][0])),''.join(sorted(s['ships'][1])))for s in parsed(state))])

def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(30,31))
 resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def decision(engine,state,player):
 args=[str(ROOT/'bin'/f'{engine}-adapter')]
 data=state if engine=='quux' else cztext(state)
 if engine=='quux':args+=['ai',str(player)]
 else:args+=[str(player)]
 usage=resource.getrusage(resource.RUSAGE_CHILDREN)
 start=time.perf_counter();p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,preexec_fn=limits,env={**os.environ,"THINK_CPU_SECONDS":"30"})
 expired=False
 try:out,err=p.communicate(data+'\n',timeout=WALL)
 except subprocess.TimeoutExpired:
  expired=True;os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 cpu=(after.ru_utime+after.ru_stime)-(usage.ru_utime+usage.ru_stime)
 candidates=[]
 for line in out.splitlines():
  m=re.fullmatch(r'CAND (\d+) ([\d.e+-]+) (.+)',line)
  if m:candidates.append(dict(depth=int(m[1]),iteration_cpu=float(m[2]),move=m[3]))
 budget_stop=expired or p.returncode in [-signal.SIGPROF,-signal.SIGXCPU]
 success=bool(candidates) and (p.returncode==0 or budget_stop)
 return dict(status='ok' if success else 'timeout' if budget_stop else 'engine_error',returncode=p.returncode,move=candidates[-1]['move'] if candidates else '',stderr=err,stdout=out,wall=time.perf_counter()-start,cpu=cpu,depth=candidates[-1]['depth'] if candidates else 0,budget_stop=budget_stop)

def validate(state,player,move):
 p=subprocess.run([str(ROOT/'bin/quux-adapter'),'ref',str(player)],input=state+'\n'+move+'\n',text=True,capture_output=True,timeout=5)
 if p.returncode:raise RuntimeError('Referee crash '+p.stderr)
 header,body=p.stdout.split('\n',1)
 if not header.startswith('RESULT '):raise RuntimeError(header)
 _,code,l0,l1=header.split()
 if code!='0':return dict(legal=False,code=int(code),state=body)
 parsed(body)
 lost=[int(l0),int(l1)]
 return dict(legal=True,state=body,winner=1 if lost==[1,0] else 0 if lost==[0,1] else 'draw' if lost==[1,1] else None)

def initial(pair):
 rng=random.Random(823701+pair)
 # Normal binary stars with unlike sizes and complementary access; both start with green large.
 combos=[('b1','r2'),('b1','r3'),('b2','r1'),('b2','r3'),('b3','r1'),('b3','r2'),('b1','y2'),('b1','y3'),('b2','y1'),('b2','y3'),('b3','y1'),('b3','y2')]
 a,b=rng.sample(combos,2)
 return f"North (0, {''.join(a)}) g3-\nSouth (1, {''.join(b)}) -g3\n"

def game(number,pair,start,folder,maxplies=400):
 state=initial(pair);row=dict(game=number,pair=pair,starting_engine=['quux','czinn'][start],initial_state=state,setup_seed=823701+pair,status='unfinished',winner='',plies=0,quux_cpu=0.,czinn_cpu=0.,quux_wall=0.,czinn_wall=0.,quux_moves=0,czinn_moves=0,illegal_engine='',reason='')
 path=folder/f'game-{number:03d}.jsonl';seen=collections.Counter();player=start;seen[key(state,player)]+=1
 begin=time.perf_counter()
 with path.open('w') as transcript:
  def emit(obj):transcript.write(json.dumps(obj)+'\n');transcript.flush()
  emit(dict(event='start',**row,cpu_budget=None,wall_limit=WALL))
  for ply in range(1,maxplies+1):
   engine=['quux','czinn'][player];choice=decision(engine,state,player)
   row[engine+'_moves']+=1;row[engine+'_cpu']+=choice['cpu'] or 0;row[engine+'_wall']+=choice['wall'];row['plies']=ply-1
   entry=dict(event='move',ply=ply,player=player,engine=engine,state_before=state,**choice)
   if choice['status']!='ok':row.update(status='unfinished',reason=choice['status']+':'+engine);emit(entry);break
   try:ref=validate(state,player,choice['move'])
   except Exception as e:row.update(status='software_error',reason=str(e));emit(entry);break
   entry['validation']=ref;emit(entry)
   if not ref['legal']:row.update(status='illegal',illegal_engine=engine,reason=f"referee_code_{ref['code']}");break
   state=ref['state'];row['plies']=ply
   if ref['winner'] is not None:
    row.update(status='completed',winner='draw' if ref['winner']=='draw' else ['quux','czinn'][ref['winner']],reason='rulebook_terminal');break
   player=1-player;k=key(state,player);seen[k]+=1
   if seen[k]>=3:row.update(status='adjudicated',reason='threefold_repetition');break
  else:row.update(status='unfinished',reason='400_ply_limit')
  row['elapsed_wall']=time.perf_counter()-begin;row['final_state']=state;emit(dict(event='end',**row))
 return row

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--games',type=int,default=4);ap.add_argument('--folder',default='pilot');ap.add_argument('--first-pair',type=int,default=0);args=ap.parse_args()
 folder=ROOT/'results'/args.folder;folder.mkdir(parents=True,exist_ok=True)
 rows=[]
 jobs=[(i+1,args.first_pair+i//2,i%2,folder) for i in range(args.games)]
 workers=1 if args.folder.startswith('pilot') else 4
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers)as pool:
  pending={pool.submit(game,*job):job[0] for job in jobs}
  for future in concurrent.futures.as_completed(pending):
   row=future.result();rows.append(row);rows.sort(key=lambda r:r['game'])
   with (folder/'summary.csv').open('w')as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
   print(json.dumps({k:row[k] for k in ['game','pair','status','winner','plies','quux_cpu','czinn_cpu','elapsed_wall','reason']}),flush=True)
 (folder/'summary.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':main()
